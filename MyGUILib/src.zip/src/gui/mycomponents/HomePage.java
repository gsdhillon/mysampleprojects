package gui.mycomponents;

/**
 */
public interface HomePage {
    public void showHomePage();
}
