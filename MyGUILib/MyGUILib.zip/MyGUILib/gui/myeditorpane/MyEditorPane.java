package gui.myeditorpane;

import javax.swing.JEditorPane;
import javax.swing.JTextPane;
import javax.swing.text.html.HTMLEditorKit;

/**
 * Class MyEditorPane
 * Created on Aug 31, 2013
 * @version 1.0.0
 * @author Gurmeet Singh
 */
public class MyEditorPane extends JEditorPane {
    private static final long serialVersionUID = 6270183148379328084L;
    public MyEditorPane() {
        // Set editor kit
        this.setEditorKitForContentType("text/xml", new XmlEditorKit());
        //this.setContentType("text/xml");
        HTMLEditorKit kit = new HTMLEditorKit();
        this.setEditorKitForContentType("text/html", kit);
    }
     
}