package gui.myeditorpane.samples;

import gui.MyLog;
import gui.myeditorpane.MyEditorPane;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;
import gui.myeventlisteners.MyWindowsAdaptor;
/**
 */
public class SampleXMLMain extends JFrame{
    String xmlText = 
    "<!-- XML Format Version 1 -->\n"
    + "<MESSAGE_10>\n"
            + "\t<TO>Ajaybir Singh</TO>\n"
            + "\t<FROM>Ishjyot Kaur</FROM>\n"
            + "\t<HEADING>Hello</HEADING>\n"
            + "\t<BODY>Hello Ajaybir, How are you!</BODY>\n"
            + "\t<SIGNED_ON>14/11/2006 18:00</SIGNED_ON>\n"
            + "\t<CERT_SNO>1234567890</CERT_SNO>\n"
    + "</MESSAGE_10>";
    public SampleXMLMain() {
        try {
            Container c = getContentPane();
            c.setLayout(new BorderLayout());
            MyEditorPane p = new MyEditorPane();
            p.setContentType("text/xml");
            p.setText(xmlText);
            c.add(p,BorderLayout.CENTER);
            //
            int width = 800;
            int height = 400;
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            setLocation((screenSize.width-width)/2, (screenSize.height-height)/2);
            setSize(new Dimension(width, height));
            addWindowListener(new MyWindowsAdaptor(){
                @Override
                public void windowClosing(WindowEvent arg0) {
                    System.exit(0);
                }

            });
        }catch(Exception e){
            
        }    
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception{
        //MyLog.setHome(".");
        MyLog.setDebug(true);
        MyLog.showDebugMessage("Debug is on");
        new SampleXMLMain().setVisible(true);
    }
}