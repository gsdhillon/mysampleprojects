-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.1.36-community


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema sampleweb
--

CREATE DATABASE IF NOT EXISTS sampleweb;
USE sampleweb;

--
-- Definition of table `detail`
--

DROP TABLE IF EXISTS `detail`;
CREATE TABLE `detail` (
  `mid` int(10) unsigned NOT NULL,
  `sno` int(10) unsigned NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`mid`,`sno`),
  CONSTRAINT `FK_detail_1` FOREIGN KEY (`mid`) REFERENCES `master` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detail`
--

/*!40000 ALTER TABLE `detail` DISABLE KEYS */;
INSERT INTO `detail` (`mid`,`sno`,`name`) VALUES 
 (1,1,'X1'),
 (1,2,'X2'),
 (1,3,'X3'),
 (2,1,'X1'),
 (2,2,'X2'),
 (2,3,'X3'),
 (3,1,'X1'),
 (3,2,'X2'),
 (3,3,'X3'),
 (4,1,'X1'),
 (4,2,'X2'),
 (4,3,'X3'),
 (5,1,'X1'),
 (5,2,'X2'),
 (5,3,'X3'),
 (7,1,'X1'),
 (7,2,'X2'),
 (7,3,'X3');
/*!40000 ALTER TABLE `detail` ENABLE KEYS */;


--
-- Definition of table `master`
--

DROP TABLE IF EXISTS `master`;
CREATE TABLE `master` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master`
--

/*!40000 ALTER TABLE `master` DISABLE KEYS */;
INSERT INTO `master` (`id`,`name`) VALUES 
 (1,'X'),
 (2,'X'),
 (3,'X'),
 (4,'X'),
 (5,'X'),
 (7,'X');
/*!40000 ALTER TABLE `master` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
