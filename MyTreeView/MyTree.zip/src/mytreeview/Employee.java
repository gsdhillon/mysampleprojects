package mytreeview;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
/**
 * Class Employee
 * Created on Aug 17, 2013
 * @version 1.0.0
 * @author
 */
public final class Employee{
    public String empno = "24196";
    public String name = "";
    public String desig = "SO / E";
    public String division = "CD";
    public String email = "gsdhill@gmail.com";
    public String phone = "22656";
    @SuppressWarnings("LeakingThisInConstructor")
    public Employee(){
    }
    @Override
    public String toString(){
        return name+", "+desig+", "+division;
    }
    //GUI Panel
    private JPanel guiPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0,0));
    private Color bgColorSelection = Color.YELLOW;//new Color(0,0,140);
    private Color[] bgColorNormal = {
        new Color(255,193,32), 
        new Color(168,234,196),
        new Color(0x00,0x99,0xcc),
        new Color(253,185,255),
        new Color(157,210,199),
        new Color(0xBB,0xBc,0x56),
        new Color(218,152,254)
    };
    private boolean updated = true;
    private boolean expanded = false;
    private JLabel getLabel(String text){
        JLabel l = new JLabel(text);
        return l;
    }
    private JLabel l1, l2,l3,l4,l5,l6;
    private void setLabelsForegroud(Color color, Font font){
        //
        l1.setForeground(color);
        l2.setForeground(color);
        l3.setForeground(color);
        l4.setForeground(color);
        l5.setForeground(color);
        l6.setForeground(color);
        //
        l1.setFont(font);
        l2.setFont(font);
        l3.setFont(font);
        l4.setFont(font);
        l5.setFont(font);
        l6.setFont(font);
    }
    private void updateGUIPanel(){
        guiPanel.removeAll();
        guiPanel.setPreferredSize(new Dimension(760, expanded?120:30));
        l1 = getLabel(name);
        l1.setPreferredSize(new Dimension(200, 30));
        guiPanel.add(l1);
        l2 = getLabel("["+empno+"]");
        l2.setPreferredSize(new Dimension(100, 30));
        guiPanel.add(l2);
        l3 = getLabel(desig);
        l3.setPreferredSize(new Dimension(80, 30));
        guiPanel.add(l3);
        l4 = getLabel(division);
        l4.setPreferredSize(new Dimension(80, 30));
        guiPanel.add(l4);
        l5 = getLabel(email);
        l5.setPreferredSize(new Dimension(160, 30));
        guiPanel.add(l5);
        l6 = getLabel(phone);
        l6.setPreferredSize(new Dimension(80, 30));
        guiPanel.add(l6);
        guiPanel.validate();
    }
    
    public JPanel getGUIPanel(boolean selected, JTree tree, int level){
        if(updated){
            updateGUIPanel();
            updated = false;
        }
        if (selected) {
            guiPanel.setBackground(bgColorSelection);
            setLabelsForegroud(Color.RED, new Font("ARIAL", Font.PLAIN, 15));
        } else {
            guiPanel.setBackground(bgColorNormal[level%bgColorNormal.length]);
            setLabelsForegroud(Color.BLACK, new Font("ARIAL", Font.PLAIN, 14));
        }
        guiPanel.setEnabled(tree.isEnabled());
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 1));
        p.add(guiPanel);
        p.setBackground(tree.getBackground());
        return p;
    }

    public void showPopup(JTree tree) {
        if(!expanded){
            askAndExpand(tree);
        }else{
            askAndCollapse(tree);
        }
        
    }

    private void askAndExpand(JTree tree) {
        int option = JOptionPane.showConfirmDialog(new JFrame(), "Show details of "+name, "", JOptionPane.YES_NO_OPTION);
        if(option == JOptionPane.YES_OPTION){
            expanded = true;
            updated = true;
        }
        tree.updateUI();
        tree.repaint();
    }
    
    private void askAndCollapse(JTree tree) {
        int option = JOptionPane.showConfirmDialog(new JFrame(), "Hide details of "+name, "", JOptionPane.YES_NO_OPTION);
        if(option == JOptionPane.YES_OPTION){
            expanded = false;
            updated = true;
        }
        tree.updateUI();
        tree.repaint();
    }
}